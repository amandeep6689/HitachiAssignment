import { browser } from "protractor";
import {Login} from "../Generic_Library/Login";
 import {Logout } from "../Generic_Library/logout";
import { RemittanceDDC } from "../Generic_Library/RemittanceDDC";



describe('Validate DDC transaction with existing benificary', function () {
  
  
   var login = new Login();
   login.Login();

   var DDC = new RemittanceDDC();
   DDC.DDC();
   DDC.NewBenificaryDDC();
   DDC.printRecepient();
   browser.sleep(10000);
   
   var logout = new Logout();
   logout.Logout(); 
   
 }); 