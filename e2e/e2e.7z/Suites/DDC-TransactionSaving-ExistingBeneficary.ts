import { browser } from "protractor";
import {Login} from "../Generic_Library/Login";
 import {Logout } from "../Generic_Library/logout";
import { RemittanceDDC } from "../Generic_Library/RemittanceDDC";



describe('Validate Swift transaction with existing benificary', function () {
  
  
   var login = new Login();
   login.Login();

   var DDC = new RemittanceDDC();
   DDC.DDC();
   DDC.ExistingBenificaryDDC();
   DDC.printRecepient();
   
   var logout = new Logout();
   logout.Logout(); 
   
 }); 