import { browser } from "protractor";
import {Login} from "../Generic_Library/Login";
 import {Logout } from "../Generic_Library/logout";
import { Remittance } from "../Generic_Library/RemittanceSwift";


describe('Validate Swift transaction with new benificary', function () {
  
  
   var login = new Login();
   login.Login();

   var swift = new Remittance();
   swift.TTR();
   swift.NewBenificaryTTR();
   swift.printRecepient();
   
   var logout = new Logout();
   logout.Logout(); 
   
 }); 