import { browser, element, by, ExpectedConditions, protractor } from "protractor";
import { using } from "jasmine-data-provider";
import { CSVCommon } from "./CSVUtility";
import { LocatorsFilePath} from "./LocatorsFilePath";

export class Login {

  constructor(){

  }
      Login() {

    var using = require('jasmine-data-provider');
    var input = new LocatorsFilePath();
    const csvCredentials = input.loginInput
    const csvcomponent = input.loginComponentids    
    var data_Creds=CSVCommon.prototype.GetDataFromCSV(csvCredentials);
    var data_Component=CSVCommon.prototype.GetDataFromCSV(csvcomponent);
    using(data_Creds, function (inputData) {
    using(data_Component, function(inputData_id)  {  
    
      browser.waitForAngularEnabled(false);
         
      it('Click country', function () {
        browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickCountry))));
            var clickCountryName = inputData_id.clickCountry;
            var click = element(by.xpath(clickCountryName));
            click.click().then(function(){  
           browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickAzureAD))));                
            })
          });

          it('Click AzureAD', function () {
            
                var clickAzureAD = element(by.xpath(inputData_id.clickAzureAD));
                clickAzureAD.click().then(function(){  
                  browser.sleep(5000);
              //  browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.enterEmail))));                
                })
              });


          it('ClickAnotherAccount', function () {

                var clickAnotherAccount = element(by.xpath(inputData_id.clickUseAnotherAccount));
                clickAnotherAccount.isPresent().then(function (result) {
                  if (result) {
                    clickAnotherAccount.click();
                  } else {
                    //do nothing
                  }
                });
      
              });

          it('Enter Username', function (){
        

            var idUserName = inputData_id.enterEmail;
            var username = element(by.xpath(idUserName));

            username.clear().then(() => {
              username.click();
              username.sendKeys(inputData.UserName);
          })
          
            var clickNextXpath = inputData_id.clickNext;
            var clickNext = element(by.xpath(clickNextXpath));
            clickNext.click().then(function(){
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.enterPassword))));
            })
          });

          it('Enter password', function (){
            //Enter Password
            var idPassword =inputData_id.enterPassword;
            var password = element(by.xpath(idPassword));
            password.clear().then(() => {
            password.click();
            password.sendKeys(inputData.Password);
            })
            var clickNextXpath = inputData_id.clickNext;
            var clickNext = element(by.xpath(clickNextXpath));
            clickNext.click().then(function(){
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickOK))));
            
            });
          });

          it('select branch', function (){

            var selectBranch= element(by.xpath(inputData_id.clickOK));
            selectBranch.click();
            browser.sleep(5000);
            var selectBranch= element(by.xpath(inputData_id.enterBranch));
            selectBranch.clear().then(() => {
              selectBranch.click();
              browser.sleep(5000);
              selectBranch.sendKeys(inputData.selectBranch);
              browser.actions().sendKeys(protractor.Key.ENTER).perform();
          })

            // browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.tillAvialable))));

          });

          it('select till and click on Next', function (){

            var next= element(by.xpath(inputData_id.clickNext1));
            next.click();
           
          var okButton = element(by.xpath(inputData_id.warningPopUp));
          browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.warningPopUp))));
          okButton.click();

          });

          it('Validate home page', function (){

            var homePage= element(by.xpath(inputData_id.landingPage));
          browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.landingPage))));
       

          });
    });
  });
}
}   