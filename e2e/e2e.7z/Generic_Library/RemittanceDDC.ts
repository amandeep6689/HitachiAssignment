import { browser, element, by, ExpectedConditions, protractor } from "protractor";
import { using } from "jasmine-data-provider";
import { CSVCommon } from "./CSVUtility";
import { LocatorsFilePath} from "./LocatorsFilePath";

export class RemittanceDDC {

    constructor(){
  
    }
        DDC() {
  
      var using = require('jasmine-data-provider');
      var input = new LocatorsFilePath();
      const csvCredentials = input.RemittanceDDCTestData
      const csvcomponent = input.RemittanceDDCComponentID    
      var data_Creds=CSVCommon.prototype.GetDataFromCSV(csvCredentials);
      var data_Component=CSVCommon.prototype.GetDataFromCSV(csvcomponent);
      using(data_Creds, function (inputData) {
      using(data_Component, function(inputData_id)  {  
      
        browser.waitForAngularEnabled(false);
        it('Click on remittance', function () {
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRemittance))));
              var clickRemittance = inputData_id.clickRemittance;
              var click = element(by.xpath(clickRemittance));
              click.click().then(function(){  
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickDDC))));                
              })
              });
        
        it('Click on DDC', function () {
              var clickOnDDC = inputData_id.clickDDC;
              var click = element(by.xpath(clickOnDDC));
              click.click().then(function(){  
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickIdNumber))));                
               })
               })
               
            it('Click on ID number', function () {
            var clickIdNumber = inputData_id.clickIdNumber;
                var clickId = element(by.xpath(clickIdNumber));
                clickId.click().then(function(){  
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickCPR))));  
                var selectCPA = element(by.xpath(inputData_id.clickCPR));
                selectCPA.click(); 
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.typeCPR))));       
                })
                });  
                  
        it('Type CPA number', function () {
          var typeCPA = inputData_id.typeCPR;
              var typeCPANumber  = element(by.xpath(typeCPA));
              typeCPANumber.clear().then(() => {
              typeCPANumber.click();
              typeCPANumber.sendKeys(inputData.CPA);
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickSearch))));    
              })   
              });   
          
        it('Click on search button', function () {
            var clickOnSearch  = element(by.xpath(inputData_id.clickSearch));
            clickOnSearch.click().then(() => {
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickNewTransaction))));
            })   
            }); 
            
        it('Click on new transaction', function () {
              var clickOnNewTransaction  = element(by.xpath(inputData_id.clickNewTransaction));
              clickOnNewTransaction.click().then(() => {
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickBenificary))));
              })   
              });      
            });
        });
      }

      ExistingBenificaryDDC() {

        var using = require('jasmine-data-provider');
        var input = new LocatorsFilePath();
        const csvCredentials = input.RemittanceDDCTestData
        const csvcomponent = input.RemittanceDDCComponentID   
        var data_Creds=CSVCommon.prototype.GetDataFromCSV(csvCredentials);
        var data_Component=CSVCommon.prototype.GetDataFromCSV(csvcomponent);
        using(data_Creds, function (inputData) {
        using(data_Component, function(inputData_id)  {  
        
          browser.waitForAngularEnabled(false);

         

          it('Select Benificary', function () {
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickBenificary)))); 
                var clickOnBenificary = element(by.xpath(inputData_id.clickBenificary));
                clickOnBenificary.click().then(function(){  
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectBeneficiary))));
                var selectBeneficiaryDropdown = element(by.xpath(inputData_id.selectBeneficiary));
                selectBeneficiaryDropdown.click();
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickBeneficiaryTransactionType))));
                })
                });
          
          it('Select beneficiary transaction type', function () {    
                var clickOnBenificaryTransactionType = element(by.xpath(inputData_id.clickBeneficiaryTransactionType));
                clickOnBenificaryTransactionType.click().then(function(){  
                  // browser.sleep(8000);
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectBeneficiaryTransactionType))));
                var selectBeneficiaryTransactionTypeDropdown = element(by.xpath(inputData_id.selectBeneficiaryTransactionType));
                  selectBeneficiaryTransactionTypeDropdown.click();
                })
                 })


          it('Select Relationship', function () {
           browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRelationship)))); 
           var clickOnRelation = element(by.xpath(inputData_id.clickRelationship));
           clickOnRelation.click().then(function(){  
           browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectRelationship))));
           var selectRelationship = element(by.xpath(inputData_id.selectRelationship));
           selectRelationship.click();
           browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickBeneficiaryTransactionType))));
           })
           });       


          it('Enter payment details', function () {    
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickSourceOfFund)))); 
            var clickOnSourceOfFund = element(by.xpath(inputData_id.clickSourceOfFund));
            clickOnSourceOfFund.click().then(function(){  
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectFundType))));
            var selectOnFundType = element(by.xpath(inputData_id.selectFundType));
            selectOnFundType.click();
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRemittancePurpose))));
            var clickRemittancePurpose = element(by.xpath(inputData_id.clickRemittancePurpose));
            clickRemittancePurpose.click();
            browser.sleep(3000);
            var selectRemittancePurpose = element(by.xpath(inputData_id.selectRemittancePurpose));
            selectRemittancePurpose.click();
              })
              })   
              
           it('Enter Source of funds and Remittance purpose', function () {    
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickSourceOfFund)))); 
              var clickOnSourceOfFund = element(by.xpath(inputData_id.clickSourceOfFund));
              clickOnSourceOfFund.click().then(function(){  
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectFundType))));
              var selectOnFundType = element(by.xpath(inputData_id.selectFundType));
              selectOnFundType.click();
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRemittancePurpose))));
              var clickRemittancePurpose = element(by.xpath(inputData_id.clickRemittancePurpose));
              clickRemittancePurpose.click();
              browser.sleep(3000);
              var selectRemittancePurpose = element(by.xpath(inputData_id.selectRemittancePurpose));
              selectRemittancePurpose.click();   
                })
                })  

            it('Enter rate type', function () {    
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRateType))));
                var clickOnRateType= element(by.xpath(inputData_id.clickRateType));
                clickOnRateType.click().then(function(){
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectRateType))));
                var selectOnRateType = element(by.xpath(inputData_id.selectRateType));
                selectOnRateType.click();
                })
                  }) 

            it('Type forex amount', function () {    
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.typeForexAmount))));
                var typeForexAmount= element(by.xpath(inputData_id.typeForexAmount));
                typeForexAmount.clear().then(function(){
                typeForexAmount.click();
                typeForexAmount.sendKeys(inputData.forexAmount)
                browser.sleep(5000);
                var clickLocalAmount= element(by.xpath(inputData_id.clickLocalAmount));
                clickLocalAmount.click();
                browser.sleep(5000)
                })
                })
                
            it('Enter Receieved amount', function () {    
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.settlementAmount))));
                var copySettlementAmount = element(by.xpath(inputData_id.settlementAmount)).getText();
                browser.sleep(5000)
                element(by.xpath(inputData_id.enterReceievedAmount)).sendKeys(copySettlementAmount);  
                  })  

            it('Click on save button', function () {    
                 browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.saveTransaction))));
                 var saveTransaction = element(by.xpath(inputData_id.saveTransaction));
                 saveTransaction.click();
                 browser.sleep(5000);
                })         
              });
          });
        }


        
       NewBenificaryDDC() {

        var using = require('jasmine-data-provider');
        var input = new LocatorsFilePath();
        const csvCredentials = input.RemittanceDDCTestData
        const csvcomponent = input.RemittanceDDCComponentID   
        var data_Creds=CSVCommon.prototype.GetDataFromCSV(csvCredentials);
        var data_Component=CSVCommon.prototype.GetDataFromCSV(csvcomponent);
        using(data_Creds, function (inputData) {
        using(data_Component, function(inputData_id)  {  
        
          browser.waitForAngularEnabled(false);

          it('Select Benificary', function () {
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickBenificary)))); 
                var clickOnBenificary = element(by.xpath(inputData_id.clickBenificary));
                clickOnBenificary.click().then(function(){  
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickCurrency))));
                })
                });
          
          it('Update correspondent bank details', function () {    
                var clickOnCurrency = element(by.xpath(inputData_id.clickCurrency));
                clickOnCurrency.click().then(function(){  
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectCurrency))));
                var selectCurrencyTypeDropdown = element(by.xpath(inputData_id.selectCurrency));
                selectCurrencyTypeDropdown.click();
                browser.sleep(5000);
                var clickOnBank = element(by.xpath(inputData_id.clickBank));
                clickOnBank.click();
                browser.sleep(5000);
                var selectBankDropdown = element(by.xpath(inputData_id.selectBank));
                selectBankDropdown.click(); 
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickBenificaryType))));
                  })
                   })

                   it('Select Benificary details', function () {     
                    var clickOnBenificaryType = element(by.xpath(inputData_id.clickBenificaryType));
                    clickOnBenificaryType.click().then(function(){  
                    browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectBeneficiaryType))));
                    var selectBeneficiary = element(by.xpath(inputData_id.selectBeneficiaryType));
                    selectBeneficiary.click();
                    browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.enterFirstName))));
                    var firstName = element(by.xpath(inputData_id.enterFirstName));
                    firstName.click();
                    firstName.sendKeys(inputData.firstName);
                    browser.sleep(5000);
                    // browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickNationality))));
                    var clickNationality = element(by.xpath(inputData_id.clickNationality));
                    clickNationality.click();
                    browser.sleep(5000);
                    var selectonNationality = element(by.xpath(inputData_id.selectNationality));
                    selectonNationality.click();
                    browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRelationship1))));
                    var clickOnRelationship = element(by.xpath(inputData_id.clickRelationship1)); 
                    clickOnRelationship.click();
                    browser.sleep(5000);
                    var selectRelationshipDropdown = element(by.xpath(inputData_id.selectRelationship1)); 
                    selectRelationshipDropdown.click();
                    browser.sleep(5000);
                    var clickOnBankSearch = element(by.xpath(inputData_id.selectBankSearch));
                    clickOnBankSearch.click();
                    browser.sleep(5000);
                    var selectBankCodeType = element(by.xpath(inputData_id.clickBankSearch1));
                    selectBankCodeType.click();
                    browser.sleep(5000);
                    var clickBranchSearch = element(by.xpath(inputData_id.selectBranchSearch));
                    clickBranchSearch.click();
                    browser.sleep(5000);
                    var selectBranchCode = element(by.xpath(inputData_id.clickBankSearch2));
                    selectBranchCode.click();
                    browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.benAddCountry))));
                    var enterAddress = element(by.xpath(inputData_id.benAddCountry));
                    enterAddress.click();
                    enterAddress.sendKeys(inputData.enterAddress);
                    browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectBenAddCountry))));
                    var clickBenBankCountry = element(by.xpath(inputData_id.selectBenAddCountry));
                    clickBenBankCountry.click();
                    browser.sleep(5000);
                    var selectBenBankCountry = element(by.xpath(inputData_id.clickBankSearch));
                    selectBenBankCountry.click();
                      })
                      })  
                      
           it('Enter payment details', function () {    
            browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickSourceOfFund)))); 
            var clickOnSourceOfFund = element(by.xpath(inputData_id.clickSourceOfFund));
            clickOnSourceOfFund.click().then(function(){ 
              browser.sleep(5000);  
            // browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectFundType))));
            var selectOnFundType = element(by.xpath(inputData_id.selectFundType));
             selectOnFundType.click();
             browser.sleep(5000);
            // browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRemittancePurpose))));
            var clickRemittancePurpose = element(by.xpath(inputData_id.clickRemittancePurpose));
            clickRemittancePurpose.click();
            browser.sleep(5000);
            var selectRemittancePurpose = element(by.xpath(inputData_id.selectRemittancePurpose));
            selectRemittancePurpose.click();
                })
                })              
              
          it('Enter rate type', function () {    
          browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.clickRateType))));
          var clickOnRateType= element(by.xpath(inputData_id.clickRateType));
          clickOnRateType.click().then(function(){
          browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.selectRateType))));
          var selectOnRateType = element(by.xpath(inputData_id.selectRateType));
          selectOnRateType.click();
          })
          }) 

            it('Type forex amount', function () {    
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.typeForexAmount))));
                var typeForexAmount= element(by.xpath(inputData_id.typeForexAmount));
                typeForexAmount.clear().then(function(){
                typeForexAmount.click();
                typeForexAmount.sendKeys(inputData.forexAmount)
                browser.sleep(5000);
                var clickLocalAmount= element(by.xpath(inputData_id.clickLocalAmount));
                clickLocalAmount.click();
                browser.sleep(5000)
                })
                })
                
            it('Enter Receieved amount', function () {    
                browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.settlementAmount))));
                var copySettlementAmount = element(by.xpath(inputData_id.settlementAmount)).getText();
                browser.sleep(5000)
                element(by.xpath(inputData_id.enterReceievedAmount)).sendKeys(copySettlementAmount);  
                  })  

            it('Click on save button', function () {    
                 browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.saveTransaction))));
                 var saveTransaction = element(by.xpath(inputData_id.saveTransaction));
                 saveTransaction.click();
                 browser.sleep(5000);
                })         
              });
          });
        }
        printRecepient() {

          var using = require('jasmine-data-provider');
          var input = new LocatorsFilePath();
          const csvCredentials = input.RemittanceDDCTestData
          const csvcomponent = input.RemittanceDDCComponentID   
          var data_Creds=CSVCommon.prototype.GetDataFromCSV(csvCredentials);
          var data_Component=CSVCommon.prototype.GetDataFromCSV(csvcomponent);
          using(data_Creds, function (inputData) {
          using(data_Component, function(inputData_id)  { 
            browser.waitForAngularEnabled(false);  

            it('Validate Print Receipt', function () {
              browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.printReceipt)))); 
                var clickOnClose = element(by.xpath(inputData_id.closeReceipt));
                clickOnClose.click().then(function(){  
                browser.sleep(5000);
                })
                });


          });
        });
      }
  
      }