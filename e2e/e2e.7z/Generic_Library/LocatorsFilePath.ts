

export class LocatorsFilePath {


    loginInput:string= './e2e/Test_Data/LoginCredentials.csv';
    loginComponentids:string= './e2e/Component_ID/LoginComponentId.csv';
    logoutComponentids:string= './e2e/Component_ID/LogoutComponentId.csv';
	
    //Clickable Link validation
    LinkClickableTestData = './e2e/Test_Data/LinkClickable.csv';
    LinkClickableComponentID = './e2e/Component_ID/LinkClickable_ComponentID.csv';

    //Clickable Link validation
    CuctomerSearchTestData = './e2e/Test_Data/CustomerSearch.csv';
    CustomerSearchComponentID = './e2e/Component_ID/CustomerSearch_ComponentID.csv';

    //Remittance Swift

    RemittanceSwiftTestData = './e2e/Test_Data/RemittanceSwift.csv';
    RemittanceSwiftComponentID = './e2e/Component_ID/RemittanceSwift.csv';

    //Remittance DDC

    RemittanceDDCTestData = './e2e/Test_Data/RemittanceDDC.csv';
    RemittanceDDCComponentID = './e2e/Component_ID/RemittanceDDC.csv';

    //Remittance DDD

    RemittanceDDDTestData = './e2e/Test_Data/RemittanceDDD.csv';
    RemittanceDDDComponentID = './e2e/Component_ID/RemittanceDDD.csv';
}