import { browser, element, by, ExpectedConditions, protractor } from "protractor";
import { using } from "jasmine-data-provider";
import { CSVCommon } from "./CSVUtility";
import { LocatorsFilePath} from "./LocatorsFilePath";

export class Logout {

  constructor(){

  }
      Logout() {

    var using = require('jasmine-data-provider');
    var input = new LocatorsFilePath();
    const csvCredentials = input.loginInput
    const csvcomponent = input.logoutComponentids    
    var data_Creds=CSVCommon.prototype.GetDataFromCSV(csvCredentials);
    var data_Component=CSVCommon.prototype.GetDataFromCSV(csvcomponent);
    using(data_Creds, function (inputData) {
    using(data_Component, function(inputData_id)  {  
    
      browser.waitForAngularEnabled(false);
         
      it('Click on Dropdown', function () {
        browser.sleep(13000);
        browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.LogoutDropdown))));
            var clickDropdown = inputData_id.LogoutDropdown;
            var click = element(by.xpath(clickDropdown));
            click.click().then(function(){  
           browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.LogoutOption))));                
            })
          });

          it('Click on logoutdropdown', function () {

            var clickLogout = inputData_id.LogoutOption;
                var clickLogoutdropdown = element(by.xpath(clickLogout));
                clickLogoutdropdown.click().then(function(){  
              //  browser.wait(ExpectedConditions.visibilityOf(browser.element(by.xpath(inputData_id.enterEmail))));                
                })
              });
       
    });
  });
}
}   